module.exports = {
  development:
    {
      db: 'mongodb://localhost/cloud-cordinator-users'
    }
}


module.exports = {
    development: {
      cc: {
          consumerKey: 'wlekrjawe23ij23r'
        , consumerSecret: 'w3ljasfdlkje'
        , callbackURL: "http://127.0.0.1:3000/auth/cloudcordinator/callback"
        //This server MUST be a different IP or domain to work correctly or Cookies will be overwritten
        , oauthServer: 'http://localhost:3003'
      },
    }
  , test: {

    }
  , production: {

    }
}
